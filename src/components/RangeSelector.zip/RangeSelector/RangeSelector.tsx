import Image from '@/components/Image/Image';
import { Text } from '@/components/Text';
import {
  colors,
  displayFlexAlignItemsCenterJustifyContentCenter,
  displayFlexAlignItemsCenterJustifyContentSpaceBetween,
  tokens,
} from '@/styles';
import {
  Box,
  Button,
  Divider,
  InputAdornment,
  Menu,
  Popover,
  Slider,
  styled,
  useMediaQuery,
} from '@mui/material';
import React, { useRef, useState } from 'react';

interface RangeSelectorNProps {
  label: string;
  onSliderChange: (
    event: Event,
    value: number | number[],
    activeThumb: number
  ) => void;
  defaultValue: number;
  sliderValue: [number, number];
  min: number;
  max: number;
  showBorder?: boolean;
  isPrice?: boolean;
  steps?: number;
}

const RangeSelectorN = ({
  label,
  onSliderChange,
  defaultValue,
  sliderValue,
  min,
  max,
  showBorder = true,
  isPrice = false,
  steps = 50,
}: RangeSelectorNProps) => {
  const isMobile = useMediaQuery((theme: any) => theme.breakpoints.down('sm'));
  const [anchorEl, setAnchorEl] = React.useState<HTMLElement | null>(null);
  const open = Boolean(anchorEl);
  const ref = useRef<HTMLDivElement | null>();

  const handleClick = (event: any) => setAnchorEl(event.currentTarget);
  const handleClose = () => setAnchorEl(null);

  console.log('first', ref?.current?.getBoundingClientRect().width);

  return (
    <>
      <Box width='100%' height={'100%'}>
        <Box
          ref={ref}
          {...displayFlexAlignItemsCenterJustifyContentSpaceBetween}
          gap={'15px'}
          width='100%'
          height={'56px'}
          sx={{
            border: `1px solid rgba(150, 150, 150, 0.24)`,
            borderRadius: '10px',
            padding: '16.5px 14px',
            paddingRight: '32px',
            position: 'relative',
            cursor: 'pointer',
          }}
          onClick={handleClick}
        >
          {label}
          <Image
            src={'/icons/caret-down.svg'}
            alt='down'
            width='20px'
            height='fit-content'
            style={{
              position: 'absolute',
              right: '7px',
              top: 'calc(50% - 0.5em)',
            }}
          />
        </Box>
        <Menu
          open={open}
          anchorEl={anchorEl}
          onClose={handleClose}
          sx={{
            marginTop: '10px',
            '& .MuiPaper-root': {
              borderRadius: '10px',
              boxShadow: '0px 26px 43px 0px rgba(0, 0, 0, 0.05)',
              border: `1px solid ${colors.greyE1}`,
              width: ref?.current?.getBoundingClientRect().width || '250px',
            },
            '& .MuiMenu-list, & .MuiList-root': {
              width: 'inherit',
              padding: '15px',
            },
          }}
          transformOrigin={{ horizontal: 'right', vertical: 'top' }}
          anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
          elevation={0}
        >
          <Text
            text={label}
            color={colors.black21}
            token={tokens.FS16FW600LH21_86R}
            textAlign='center'
            styles={{
              marginBottom: '15px',
            }}
          />
          <Box
            {...displayFlexAlignItemsCenterJustifyContentCenter}
            gap={'10px'}
          >
            <Text
              text={
                isPrice
                  ? `$${sliderValue[0].toString()}`
                  : sliderValue[0].toString()
              }
              color={colors.black21}
              token={tokens.FS20FW600LH22_72SB}
              textAlign='center'
              styles={{
                border: `1px solid ${colors.greyDE}`,
                padding: '8px 15px',
                borderRadius: '10px',
                minWidth: '80px',
              }}
            />
            <Text
              text={'-'}
              color={colors.black21}
              token={tokens.FS20FW600LH22_72SB}
              textAlign='center'
            />
            <Text
              text={
                isPrice
                  ? `$${sliderValue[1].toString()}`
                  : sliderValue[1].toString()
              }
              color={colors.black21}
              token={tokens.FS20FW600LH22_72SB}
              textAlign='center'
              styles={{
                border: `1px solid ${colors.greyDE}`,
                padding: '8px 15px',
                borderRadius: '10px',
                minWidth: '80px',
              }}
            />
          </Box>
          <Box
            width='100%'
            height='100%'
            display='flex'
            sx={{ overflowX: 'hidden' }}
            mt={1}
          >
            <SliderExt
              value={sliderValue}
              onChange={onSliderChange}
              //   valueLabelDisplay='auto'
              min={min}
              max={max}
              step={steps}
              sx={{
                width: '90%',
                marginInline: 'auto',
              }}
            />
          </Box>
        </Menu>
      </Box>
    </>
  );
};

export const PopoverExt = styled(Popover)(({ theme }) => ({
  '& .MuiPopover-paper': {
    display: 'flex',
    flexDirection: 'column',
    gap: '1rem',
    paddingBlock: '1rem',
    overflow: 'hidden',
    '& > div': {
      paddingInline: '1rem',
    },
  },
}));

const SliderExt = styled(Slider)(({ theme }) => ({
  color: colors.black21,
  '& .MuiSlider-valueLabel': { zIndex: 2222 },
  '& .MuiSlider-thumb': {
    color: '#fff',
    border: `1px solid ${theme.palette.grey[500]}`,
    boxShadow: 'rgba(0, 0, 0, 0.1) -4px 9px 25px -6px',
  },
  '& .MuiSlider-track': {
    backgroundColor: colors.black21,
  },
}));

export default RangeSelectorN;
